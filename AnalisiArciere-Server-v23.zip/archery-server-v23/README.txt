# Analisi Arciere - Server Archivio
## Polisportiva Gonone Dorgali - Tiro con l'Arco

---

## 📦 Contenuto

```
AnalisiArciere-Server/
├── AVVIA_SERVER.bat    ← Doppio click per avviare
├── server.py           ← Server Python
├── README.txt          ← Questo file
└── app/
    ├── index.html      ← App principale (v20)
    ├── manifest.json   ← Manifest PWA
    ├── sw.js           ← Service Worker
    ├── logo-pol.png    ← Logo
    └── v*.html         ← Versioni precedenti
```

---

## 🚀 Installazione

### 1. Requisiti
- Windows 10/11
- Python 3.8+ (https://www.python.org/downloads/)
  - Durante l'installazione, spunta "Add Python to PATH"
- FFmpeg (opzionale, per conversione MP4)
  - Scarica da: https://ffmpeg.org/download.html
  - Aggiungi alla PATH di sistema

### 2. Estrai il pacchetto
Estrai lo ZIP in `C:\AnalisiArciere-Server\`

### 3. Avvia il server
Doppio click su `AVVIA_SERVER.bat`

---

## 📱 Uso

### Primo accesso (CON internet)
1. Sul telefono, vai su Cloudflare (es. https://analisi-arciere.pages.dev)
2. Clicca su "Versioni" → "Installa Analisi Arciere"
3. L'app si installa sul telefono

### Nel club (SENZA internet)
1. Avvia il server sul PC
2. Collega il telefono al WiFi del club
3. L'app rileva automaticamente il server
4. Puoi salvare/vedere i video nell'archivio

### Archivio video
I video vengono salvati in:
```
C:\AnalisiArciere\archivio\
├── Mario_Rossi\
│   ├── 2025-12-15_10-30-00.webm
│   └── 2025-12-15_10-35-22.mp4
├── Giulia_Bianchi\
│   └── ...
└── ...
```

---

## 🔧 API Server

Il server espone queste API:

| Endpoint | Metodo | Descrizione |
|----------|--------|-------------|
| /api/status | GET | Stato server |
| /api/athletes | GET | Lista atleti |
| /api/videos/{nome} | GET | Video di un atleta |
| /api/video/{path} | GET | Scarica video |
| /api/upload | POST | Carica video |
| /api/convert | POST | Converti in MP4 |
| /api/delete | POST | Elimina video |

---

## ⚠️ Risoluzione Problemi

### "Python non riconosciuto"
Reinstalla Python e spunta "Add Python to PATH"

### "Impossibile connettersi"
- Verifica che PC e telefono siano sulla stessa rete
- Controlla il firewall di Windows

### Conversione MP4 non funziona
- Installa FFmpeg
- Aggiungi FFmpeg alla PATH di Windows

---

## 📞 Supporto

Polisportiva Gonone Dorgali - Tiro con l'Arco

---

Versione: 20
Data: Dicembre 2025
