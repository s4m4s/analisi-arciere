#!/usr/bin/env python3
import http.server, socketserver, os, socket
PORT = 8000
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory="app", **k)
    def end_headers(s): s.send_header('Cache-Control','no-cache'); super().end_headers()
def ip():
    try: s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.connect(("8.8.8.8",80));i=s.getsockname()[0];s.close();return i
    except: return "localhost"
if __name__=="__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print(f"\n  ANALISI ARCIERE v36\n  http://localhost:{PORT}\n  http://{ip()}:{PORT}\n")
    with socketserver.TCPServer(("",PORT),H) as h:
        try: h.serve_forever()
        except KeyboardInterrupt: print("\nStop.")
