#!/usr/bin/env python3
"""
=============================================================================
    ANALISI ARCIERE - SERVER LOCALE v38
    Polisportiva Gonone Dorgali - Tiro con l'Arco
=============================================================================

Server per analisi video con MediaPipe.
Riceve video dall'app, analizza frame per frame, ritorna JSON con pose.

Avvio: python server.py
API: http://localhost:5000
"""

import os
import sys
import json
import tempfile
import time
import socket
from datetime import datetime

# Flask
try:
    from flask import Flask, request, jsonify
    from flask_cors import CORS
except ImportError:
    print("❌ Flask non installato. Esegui: pip install flask flask-cors")
    sys.exit(1)

# MediaPipe
try:
    import mediapipe as mp
except ImportError:
    print("❌ MediaPipe non installato. Esegui: pip install mediapipe")
    sys.exit(1)

# OpenCV
try:
    import cv2
except ImportError:
    print("❌ OpenCV non installato. Esegui: pip install opencv-python")
    sys.exit(1)

# NumPy
try:
    import numpy as np
except ImportError:
    print("❌ NumPy non installato. Esegui: pip install numpy")
    sys.exit(1)

# ============================================================================
# CONFIGURAZIONE
# ============================================================================

PORT = 5000
HOST = '0.0.0.0'  # Accetta connessioni da qualsiasi IP

app = Flask(__name__, static_folder='app', static_url_path='')
CORS(app)  # Permette richieste cross-origin dall'app

# MediaPipe Holistic (corpo + mani + faccia)
mp_holistic = mp.solutions.holistic
mp_pose = mp.solutions.pose

# ============================================================================
# PAGINA PRINCIPALE - Serve l'app
# ============================================================================

@app.route('/')
def index():
    """Serve la pagina principale dell'app"""
    return app.send_static_file('index.html')

@app.route('/app.html')
def serve_app():
    """Serve l'app principale"""
    return app.send_static_file('app.html')

# ============================================================================
# UTILITÀ
# ============================================================================

def get_local_ip():
    """Trova l'IP locale del PC sulla rete"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def landmarks_to_dict(landmarks, width, height):
    """Converte landmarks MediaPipe in dizionario"""
    if not landmarks:
        return None
    return [
        {
            'x': lm.x,
            'y': lm.y,
            'z': lm.z if hasattr(lm, 'z') else 0,
            'visibility': lm.visibility if hasattr(lm, 'visibility') else 1,
            'px': int(lm.x * width),
            'py': int(lm.y * height)
        }
        for lm in landmarks.landmark
    ]

# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health():
    """Check se il server è attivo"""
    return jsonify({
        'status': 'ok',
        'server': 'AnalisiArciere Server',
        'version': '38',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/info', methods=['GET'])
def info():
    """Informazioni sul server"""
    return jsonify({
        'name': 'Analisi Arciere - Server Locale',
        'version': '38',
        'models': ['holistic', 'pose'],
        'capabilities': ['frame-by-frame', 'full-video'],
        'max_video_duration': 300,  # 5 minuti
        'max_file_size': 100 * 1024 * 1024  # 100MB
    })

@app.route('/api/analyze', methods=['POST'])
def analyze_video():
    """
    Analizza un video completo frame per frame.
    
    Input: video file (multipart/form-data)
    Params:
        - model: 'holistic' o 'pose' (default: holistic)
        - fps: frame per secondo da analizzare (default: 30)
        - quality: 0-2 complessità modello (default: 1)
    
    Output: JSON con pose per ogni frame
    """
    
    # Verifica che ci sia un file
    if 'video' not in request.files:
        return jsonify({'error': 'Nessun video ricevuto'}), 400
    
    video_file = request.files['video']
    if video_file.filename == '':
        return jsonify({'error': 'Nome file vuoto'}), 400
    
    # Parametri
    model_type = request.form.get('model', 'holistic')
    target_fps = int(request.form.get('fps', 30))
    quality = int(request.form.get('quality', 1))  # 0=lite, 1=full, 2=heavy
    
    print(f"\n📹 Ricevuto video: {video_file.filename}")
    print(f"   Modello: {model_type}, FPS: {target_fps}, Qualità: {quality}")
    
    # Salva video temporaneo
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, 'video.mp4')
    video_file.save(temp_path)
    
    try:
        # Apri video
        cap = cv2.VideoCapture(temp_path)
        if not cap.isOpened():
            return jsonify({'error': 'Impossibile aprire il video'}), 400
        
        # Info video
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        duration = total_frames / video_fps if video_fps > 0 else 0
        
        print(f"   Durata: {duration:.1f}s, Frame: {total_frames}, Risoluzione: {width}x{height}")
        
        # Calcola quali frame analizzare
        frame_skip = max(1, int(video_fps / target_fps))
        frames_to_analyze = list(range(0, total_frames, frame_skip))
        
        print(f"   Frame da analizzare: {len(frames_to_analyze)}")
        
        # Inizializza modello
        results_data = {
            'video_info': {
                'width': width,
                'height': height,
                'fps': video_fps,
                'duration': duration,
                'total_frames': total_frames
            },
            'model': model_type,
            'quality': quality,
            'frames': {}
        }
        
        start_time = time.time()
        
        if model_type == 'holistic':
            # MediaPipe Holistic (corpo + mani + faccia)
            with mp_holistic.Holistic(
                static_image_mode=True,
                model_complexity=quality,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            ) as holistic:
                
                for i, frame_num in enumerate(frames_to_analyze):
                    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
                    ret, frame = cap.read()
                    
                    if not ret:
                        continue
                    
                    # Converti BGR -> RGB
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    
                    # Analizza
                    results = holistic.process(rgb_frame)
                    
                    frame_data = {
                        'time': frame_num / video_fps,
                        'pose': landmarks_to_dict(results.pose_landmarks, width, height),
                        'left_hand': landmarks_to_dict(results.left_hand_landmarks, width, height),
                        'right_hand': landmarks_to_dict(results.right_hand_landmarks, width, height),
                        'face': landmarks_to_dict(results.face_landmarks, width, height) if results.face_landmarks else None
                    }
                    
                    results_data['frames'][str(frame_num)] = frame_data
                    
                    # Progress
                    if (i + 1) % 10 == 0:
                        progress = (i + 1) / len(frames_to_analyze) * 100
                        print(f"   Progresso: {progress:.0f}%")
        
        else:
            # MediaPipe Pose (solo corpo, più veloce)
            with mp_pose.Pose(
                static_image_mode=True,
                model_complexity=quality,
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            ) as pose:
                
                for i, frame_num in enumerate(frames_to_analyze):
                    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
                    ret, frame = cap.read()
                    
                    if not ret:
                        continue
                    
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    results = pose.process(rgb_frame)
                    
                    frame_data = {
                        'time': frame_num / video_fps,
                        'pose': landmarks_to_dict(results.pose_landmarks, width, height)
                    }
                    
                    results_data['frames'][str(frame_num)] = frame_data
                    
                    if (i + 1) % 10 == 0:
                        progress = (i + 1) / len(frames_to_analyze) * 100
                        print(f"   Progresso: {progress:.0f}%")
        
        cap.release()
        
        elapsed = time.time() - start_time
        results_data['analysis_time'] = elapsed
        results_data['frames_analyzed'] = len(results_data['frames'])
        
        print(f"✅ Analisi completata in {elapsed:.1f}s")
        print(f"   Frame analizzati: {len(results_data['frames'])}")
        
        return jsonify(results_data)
    
    except Exception as e:
        print(f"❌ Errore: {str(e)}")
        return jsonify({'error': str(e)}), 500
    
    finally:
        # Pulizia
        try:
            os.remove(temp_path)
            os.rmdir(temp_dir)
        except:
            pass

@app.route('/api/analyze-frame', methods=['POST'])
def analyze_single_frame():
    """
    Analizza un singolo frame (immagine).
    Utile per analisi real-time o singoli screenshot.
    
    Input: image file (multipart/form-data)
    Output: JSON con pose
    """
    
    if 'image' not in request.files:
        return jsonify({'error': 'Nessuna immagine ricevuta'}), 400
    
    image_file = request.files['image']
    model_type = request.form.get('model', 'holistic')
    quality = int(request.form.get('quality', 1))
    
    # Leggi immagine
    file_bytes = np.frombuffer(image_file.read(), np.uint8)
    frame = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    
    if frame is None:
        return jsonify({'error': 'Impossibile decodificare immagine'}), 400
    
    height, width = frame.shape[:2]
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    if model_type == 'holistic':
        with mp_holistic.Holistic(
            static_image_mode=True,
            model_complexity=quality,
            min_detection_confidence=0.5
        ) as holistic:
            results = holistic.process(rgb_frame)
            
            return jsonify({
                'width': width,
                'height': height,
                'pose': landmarks_to_dict(results.pose_landmarks, width, height),
                'left_hand': landmarks_to_dict(results.left_hand_landmarks, width, height),
                'right_hand': landmarks_to_dict(results.right_hand_landmarks, width, height),
                'face': landmarks_to_dict(results.face_landmarks, width, height) if results.face_landmarks else None
            })
    else:
        with mp_pose.Pose(
            static_image_mode=True,
            model_complexity=quality,
            min_detection_confidence=0.5
        ) as pose:
            results = pose.process(rgb_frame)
            
            return jsonify({
                'width': width,
                'height': height,
                'pose': landmarks_to_dict(results.pose_landmarks, width, height)
            })

# ============================================================================
# MAIN
# ============================================================================

def print_banner():
    local_ip = get_local_ip()
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║     █████╗ ███╗   ██╗ █████╗ ██╗     ██╗███████╗██╗              ║
║    ██╔══██╗████╗  ██║██╔══██╗██║     ██║██╔════╝██║              ║
║    ███████║██╔██╗ ██║███████║██║     ██║███████╗██║              ║
║    ██╔══██║██║╚██╗██║██╔══██║██║     ██║╚════██║██║              ║
║    ██║  ██║██║ ╚████║██║  ██║███████╗██║███████║██║              ║
║    ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝              ║
║                                                                  ║
║              █████╗ ██████╗  ██████╗██╗███████╗██████╗ ███████╗  ║
║             ██╔══██╗██╔══██╗██╔════╝██║██╔════╝██╔══██╗██╔════╝  ║
║             ███████║██████╔╝██║     ██║█████╗  ██████╔╝█████╗    ║
║             ██╔══██║██╔══██╗██║     ██║██╔══╝  ██╔══██╗██╔══╝    ║
║             ██║  ██║██║  ██║╚██████╗██║███████╗██║  ██║███████╗  ║
║             ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝  ║
║                                                                  ║
║                    SERVER LOCALE v38                             ║
║           Polisportiva Gonone Dorgali - Tiro con l'Arco          ║
║                                                                  ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║""")
    print(f"║   🌐 Server attivo su:                                          ║")
    print(f"║      • http://localhost:{PORT}                                   ║")
    print(f"║      • http://{local_ip}:{PORT}                              ║")
    print(f"║                                                                  ║")
    print(f"║   📱 Apri nel browser:    http://{local_ip}                          ║")
    print("""║                                                                  ║
║   API disponibili:                                               ║
║      • GET  /api/health    - Verifica connessione                ║
║      • GET  /api/info      - Info server                         ║
║      • POST /api/analyze   - Analizza video completo             ║
║      • POST /api/analyze-frame - Analizza singolo frame          ║
║                                                                  ║
║   Premi Ctrl+C per fermare il server                             ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
""")

if __name__ == '__main__':
    print_banner()
    
    # Disabilita log Flask verbose
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.WARNING)
    
    # Avvia server
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
