================================================================================
                ANALISI ARCIERE - SERVER LOCALE v38
              Polisportiva Gonone Dorgali - Tiro con l'Arco
================================================================================

CONTENUTO CARTELLA
------------------
• server.py          - Server Python principale
• requirements.txt   - Dipendenze Python
• INSTALLA.bat       - Installazione automatica (Windows)
• AVVIA_SERVER.bat   - Avvio server (Windows)
• installa.sh        - Installazione automatica (Mac/Linux)
• avvia_server.sh    - Avvio server (Mac/Linux)
• README.txt         - Questo file


REQUISITI
---------
• Python 3.8 o superiore
• Connessione alla stessa rete WiFi del telefono/tablet


INSTALLAZIONE VELOCE
--------------------

WINDOWS:
1. Scarica Python da https://www.python.org/downloads/
   ⚠️ Durante l'installazione seleziona "Add Python to PATH"
2. Doppio click su INSTALLA.bat
3. Attendi il completamento

MAC:
1. Apri Terminale
2. Installa Python: brew install python3
3. Esegui: chmod +x installa.sh && ./installa.sh

LINUX:
1. Apri Terminale
2. Installa Python: sudo apt install python3 python3-pip
3. Esegui: chmod +x installa.sh && ./installa.sh


AVVIO SERVER
------------

WINDOWS:
• Doppio click su AVVIA_SERVER.bat

MAC/LINUX:
• Apri Terminale nella cartella
• Esegui: ./avvia_server.sh

Il server mostrerà l'indirizzo IP da inserire nell'app.
Esempio: 192.168.1.100


CONFIGURAZIONE APP
------------------
1. Apri l'app Analisi Arciere sul telefono/tablet
2. Vai in Impostazioni (menu hamburger)
3. Nella sezione "Server Analisi" inserisci l'IP mostrato dal server
4. Premi "Test" per verificare la connessione
5. Seleziona "Server Locale" come modalità analisi


RISOLUZIONE PROBLEMI
--------------------

"Python non trovato"
→ Installa Python e assicurati che sia nel PATH

"Porta già in uso"
→ Chiudi altri programmi che usano la porta 5000
→ Oppure modifica PORT in server.py

"Connessione rifiutata dall'app"
→ Verifica che PC e telefono siano sulla stessa rete WiFi
→ Controlla che il firewall permetta connessioni sulla porta 5000
→ Su Windows: consenti l'accesso quando richiesto dal firewall

"Analisi lenta"
→ Chiudi altri programmi pesanti
→ Riduci la qualità nelle impostazioni (quality=0 invece di 1)


API DISPONIBILI
---------------

GET /api/health
  Verifica se il server è attivo
  Risposta: {"status": "ok", "version": "38"}

GET /api/info
  Informazioni sul server
  Risposta: {"name": "...", "models": [...], ...}

POST /api/analyze
  Analizza video completo
  Body: multipart/form-data con campo "video"
  Params: model (holistic/pose), fps (default 30), quality (0-2)
  Risposta: JSON con pose per ogni frame

POST /api/analyze-frame
  Analizza singola immagine
  Body: multipart/form-data con campo "image"
  Risposta: JSON con pose


SUPPORTO
--------
Per problemi o suggerimenti contatta la Polisportiva Gonone Dorgali

================================================================================
