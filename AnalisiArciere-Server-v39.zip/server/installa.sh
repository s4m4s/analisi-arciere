#!/bin/bash

echo ""
echo "══════════════════════════════════════════════════════════════"
echo "    ANALISI ARCIERE - INSTALLAZIONE SERVER v38"
echo "    Polisportiva Gonone Dorgali - Tiro con l'Arco"
echo "══════════════════════════════════════════════════════════════"
echo ""

# Verifica Python
echo "[1/4] Verifica Python..."
if ! command -v python3 &> /dev/null; then
    echo ""
    echo "❌ Python3 non trovato!"
    echo ""
    echo "   Installalo con:"
    echo "   • Mac: brew install python3"
    echo "   • Linux: sudo apt install python3 python3-pip"
    echo ""
    exit 1
fi
echo "✅ Python trovato: $(python3 --version)"

# Aggiorna pip
echo ""
echo "[2/4] Aggiornamento pip..."
python3 -m pip install --upgrade pip --quiet

# Installa dipendenze
echo ""
echo "[3/4] Installazione dipendenze..."
python3 -m pip install -r requirements.txt --quiet

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Errore durante l'installazione"
    echo "   Prova: pip3 install flask flask-cors mediapipe opencv-python numpy"
    exit 1
fi
echo "✅ Dipendenze installate"

# Test
echo ""
echo "[4/4] Verifica installazione..."
python3 -c "import flask; import mediapipe; import cv2; print('✅ Tutti i moduli OK')"

echo ""
echo "══════════════════════════════════════════════════════════════"
echo "    ✅ INSTALLAZIONE COMPLETATA!"
echo "══════════════════════════════════════════════════════════════"
echo ""
echo "   Per avviare il server: ./avvia_server.sh"
echo "   Oppure: python3 server.py"
echo ""
