================================================================================
                    ANALISI ARCIERE - SERVER LOCALE v33
                 Polisportiva Gonone Dorgali - Tiro con l'Arco
================================================================================

REQUISITI:
- Python 3.x installato (https://www.python.org/downloads/)

ISTRUZIONI:

1. WINDOWS:
   - Doppio click su "AVVIA_SERVER.bat"
   - Oppure apri il terminale e digita: python server.py

2. MAC/LINUX:
   - Apri il terminale nella cartella
   - Digita: python3 server.py

3. ACCESSO:
   - Da questo PC: http://localhost:8000
   - Da tablet/smartphone sulla stessa rete WiFi: 
     usa l'indirizzo IP mostrato nel terminale
     (es. http://192.168.1.100:8000)

4. PER FERMARE:
   - Premi Ctrl+C nel terminale

NOVITA' v33:
- Header compatto con menu hamburger
- Playback controls visibili in fullscreen
- Fix deformazione video durante analisi
- Controlli scrollabili su schermi piccoli

CONTENUTO CARTELLA:
- server.py         : Server Python
- AVVIA_SERVER.bat  : Avvio rapido Windows
- README.txt        : Questo file
- app/              : File dell'applicazione
  - index.html      : Launcher
  - app.html        : Applicazione principale
  - sw.js           : Service Worker per PWA
  - manifest.json   : Manifest PWA
  - logo-pol.png    : Logo

Per supporto: [tuo contatto]
================================================================================
