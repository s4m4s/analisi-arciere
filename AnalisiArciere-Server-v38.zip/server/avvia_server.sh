#!/bin/bash

# Vai nella cartella dello script
cd "$(dirname "$0")"

# Avvia server
python3 server.py
