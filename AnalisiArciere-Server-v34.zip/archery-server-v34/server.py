#!/usr/bin/env python3
"""
Server locale per Analisi Arciere PWA
Avvia con: python server.py
Accedi da: http://localhost:8000 o http://[IP-LOCALE]:8000
"""

import http.server
import socketserver
import os
import socket

PORT = 8000
DIRECTORY = "app"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def end_headers(self):
        # Headers per PWA e caching
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

def get_local_ip():
    """Trova l'IP locale della macchina"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "localhost"

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    local_ip = get_local_ip()
    
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║           ANALISI ARCIERE - SERVER LOCALE v34                ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Server avviato su porta {PORT}                               ║
║                                                              ║
║  Accedi da questo PC:                                        ║
║  → http://localhost:{PORT}                                    ║
║                                                              ║
║  Accedi da altri dispositivi sulla stessa rete:              ║
║  → http://{local_ip}:{PORT}                                   ║
║                                                              ║
║  Premi Ctrl+C per fermare il server                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
""")
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer fermato.")
