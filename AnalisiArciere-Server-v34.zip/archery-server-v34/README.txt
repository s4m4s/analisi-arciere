================================================================================
                    ANALISI ARCIERE - SERVER LOCALE v34
                 Polisportiva Gonone Dorgali - Tiro con l'Arco
================================================================================

REQUISITI:
- Python 3.x installato (https://www.python.org/downloads/)

ISTRUZIONI:

1. WINDOWS:
   - Doppio click su "AVVIA_SERVER.bat"
   - Oppure apri il terminale e digita: python server.py

2. MAC/LINUX:
   - Apri il terminale nella cartella
   - Digita: python3 server.py

3. ACCESSO:
   - Da questo PC: http://localhost:8000
   - Da tablet/smartphone sulla stessa rete WiFi: 
     usa l'indirizzo IP mostrato nel terminale
     (es. http://192.168.1.100:8000)

4. PER FERMARE:
   - Premi Ctrl+C nel terminale

NOVITA' v34:
- Menu hamburger a fianco del titolo (non a destra)
- Fix deformazione video durante analisi live
- Pulsante fullscreen nei controlli playback
- Controlli playback su più righe (tutti visibili)

CONTENUTO CARTELLA:
- server.py         : Server Python
- AVVIA_SERVER.bat  : Avvio rapido Windows
- README.txt        : Questo file
- app/              : File dell'applicazione

Per supporto: [tuo contatto]
================================================================================
