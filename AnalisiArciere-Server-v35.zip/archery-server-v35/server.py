#!/usr/bin/env python3
"""
Server locale per Analisi Arciere PWA v35
Avvia con: python server.py
Accedi da: http://localhost:8000 o http://[IP-LOCALE]:8000
"""

import http.server
import socketserver
import os
import socket

PORT = 8000
DIRECTORY = "app"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "localhost"

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    local_ip = get_local_ip()
    
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║           ANALISI ARCIERE - SERVER LOCALE v35                ║
╠══════════════════════════════════════════════════════════════╣
║  Server avviato su porta {PORT}                               ║
║  Da questo PC: http://localhost:{PORT}                        ║
║  Da altri dispositivi: http://{local_ip}:{PORT}                ║
║  Premi Ctrl+C per fermare                                    ║
╚══════════════════════════════════════════════════════════════╝
""")
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer fermato.")
