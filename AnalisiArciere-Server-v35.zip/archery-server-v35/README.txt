================================================================================
                    ANALISI ARCIERE - SERVER LOCALE v35
================================================================================

NOVITA' v35:
- Video con proporzioni stabili (no deformazione)
- Menu dropdown non esce piu dallo schermo
- Controlli playback su 2 righe (tutto visibile)
- Menu fullscreen con controlli playback completi:
  * Play/Pausa, Frame avanti/indietro
  * Controllo velocita
  * Analisi AI direttamente da fullscreen

ISTRUZIONI:
1. Windows: Doppio click su AVVIA_SERVER.bat
2. Mac/Linux: python3 server.py
3. Accedi da browser: http://localhost:8000
4. Da tablet/smartphone: usa IP mostrato nel terminale

================================================================================
