ANALISI ARCIERE v35
===================
1. Windows: doppio click AVVIA_SERVER.bat
2. Mac/Linux: python3 server.py
3. Apri http://localhost:8000
