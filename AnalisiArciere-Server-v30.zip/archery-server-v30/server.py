#!/usr/bin/env python3
"""
Analisi Arciere - Server Archivio
Polisportiva Gonone Dorgali - Tiro con l'Arco

Server locale per gestire l'archivio video degli atleti.
"""

import os
import json
import subprocess
import shutil
from datetime import datetime
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import parse_qs, urlparse, unquote
import cgi

# Configurazione
ARCHIVE_PATH = Path("C:/AnalisiArciere/archivio")
APP_PATH = Path(__file__).parent / "app"
PORT = 8080
HOST = "0.0.0.0"

# Crea cartella archivio se non esiste
ARCHIVE_PATH.mkdir(parents=True, exist_ok=True)

class ArchiveHandler(SimpleHTTPRequestHandler):
    """Handler per le richieste HTTP con supporto API"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(APP_PATH), **kwargs)
    
    def end_headers(self):
        # CORS headers
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()
    
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        # API endpoints
        if path == '/api/status':
            self.send_json({'status': 'ok', 'version': '20'})
        
        elif path == '/api/athletes':
            self.get_athletes()
        
        elif path.startswith('/api/videos/'):
            athlete = unquote(path.split('/api/videos/')[1])
            self.get_videos(athlete)
        
        elif path.startswith('/api/video/'):
            # Serve video file
            video_path = unquote(path.split('/api/video/')[1])
            self.serve_video(video_path)
        
        else:
            # Serve static files
            super().do_GET()
    
    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        
        if path == '/api/upload':
            self.handle_upload()
        
        elif path == '/api/convert':
            self.handle_convert()
        
        elif path == '/api/delete':
            self.handle_delete()
        
        else:
            self.send_error(404, 'Not Found')
    
    def send_json(self, data):
        """Invia risposta JSON"""
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())
    
    def get_athletes(self):
        """Lista tutti gli atleti con video"""
        athletes = []
        if ARCHIVE_PATH.exists():
            for folder in ARCHIVE_PATH.iterdir():
                if folder.is_dir():
                    video_count = len(list(folder.glob('*.webm')) + list(folder.glob('*.mp4')))
                    athletes.append({
                        'name': folder.name,
                        'videoCount': video_count
                    })
        self.send_json(athletes)
    
    def get_videos(self, athlete):
        """Lista video di un atleta"""
        athlete_path = ARCHIVE_PATH / athlete
        videos = []
        
        if athlete_path.exists():
            for video_file in sorted(athlete_path.iterdir(), reverse=True):
                if video_file.suffix in ['.webm', '.mp4']:
                    stat = video_file.stat()
                    videos.append({
                        'name': video_file.name,
                        'path': f"{athlete}/{video_file.name}",
                        'size': stat.st_size,
                        'date': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        'format': video_file.suffix[1:]
                    })
        
        self.send_json(videos)
    
    def serve_video(self, video_path):
        """Serve un file video"""
        full_path = ARCHIVE_PATH / video_path
        
        if not full_path.exists():
            self.send_error(404, 'Video not found')
            return
        
        # Determina content type
        content_type = 'video/webm' if full_path.suffix == '.webm' else 'video/mp4'
        
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', full_path.stat().st_size)
        self.end_headers()
        
        with open(full_path, 'rb') as f:
            shutil.copyfileobj(f, self.wfile)
    
    def handle_upload(self):
        """Gestisce upload video"""
        content_type = self.headers.get('Content-Type')
        
        if not content_type or 'multipart/form-data' not in content_type:
            self.send_error(400, 'Invalid content type')
            return
        
        # Parse multipart form data
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={
                'REQUEST_METHOD': 'POST',
                'CONTENT_TYPE': content_type
            }
        )
        
        # Get fields
        video_field = form['video']
        athlete = form.getvalue('athlete', 'Sconosciuto')
        timestamp = form.getvalue('timestamp', datetime.now().isoformat())
        
        # Sanitize athlete name
        athlete = "".join(c for c in athlete if c.isalnum() or c in (' ', '-', '_')).strip()
        if not athlete:
            athlete = 'Sconosciuto'
        
        # Create athlete folder
        athlete_path = ARCHIVE_PATH / athlete
        athlete_path.mkdir(parents=True, exist_ok=True)
        
        # Generate filename
        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        filename = dt.strftime('%Y-%m-%d_%H-%M-%S') + '.webm'
        video_path = athlete_path / filename
        
        # Save video
        with open(video_path, 'wb') as f:
            f.write(video_field.file.read())
        
        self.send_json({
            'success': True,
            'path': f"{athlete}/{filename}",
            'message': 'Video caricato con successo'
        })
    
    def handle_convert(self):
        """Converte video in MP4"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        data = json.loads(body)
        
        video_path = data.get('path')
        if not video_path:
            self.send_error(400, 'Path mancante')
            return
        
        input_path = ARCHIVE_PATH / video_path
        if not input_path.exists():
            self.send_error(404, 'Video non trovato')
            return
        
        # Output path
        output_path = input_path.with_suffix('.mp4')
        
        # Check if FFmpeg is available
        try:
            subprocess.run(['ffmpeg', '-version'], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.send_json({
                'success': False,
                'error': 'FFmpeg non installato. Scaricalo da https://ffmpeg.org'
            })
            return
        
        # Convert
        try:
            subprocess.run([
                'ffmpeg', '-i', str(input_path),
                '-c:v', 'libx264', '-preset', 'fast',
                '-c:a', 'aac', '-y',
                str(output_path)
            ], capture_output=True, check=True)
            
            self.send_json({
                'success': True,
                'path': str(output_path.relative_to(ARCHIVE_PATH)),
                'message': 'Conversione completata'
            })
        except subprocess.CalledProcessError as e:
            self.send_json({
                'success': False,
                'error': f'Errore conversione: {e.stderr.decode()}'
            })
    
    def handle_delete(self):
        """Elimina un video"""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        data = json.loads(body)
        
        video_path = data.get('path')
        if not video_path:
            self.send_error(400, 'Path mancante')
            return
        
        full_path = ARCHIVE_PATH / video_path
        if not full_path.exists():
            self.send_error(404, 'Video non trovato')
            return
        
        try:
            full_path.unlink()
            self.send_json({
                'success': True,
                'message': 'Video eliminato'
            })
        except Exception as e:
            self.send_json({
                'success': False,
                'error': str(e)
            })


def get_local_ip():
    """Trova l'IP locale della macchina"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "localhost"


def main():
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║                                                          ║")
    print("║       ANALISI ARCIERE - SERVER ARCHIVIO                  ║")
    print("║       Polisportiva Gonone Dorgali - Tiro con l'Arco      ║")
    print("║                                                          ║")
    print("╚══════════════════════════════════════════════════════════╝")
    print()
    
    ip = get_local_ip()
    
    print(f"  📁 Archivio video: {ARCHIVE_PATH}")
    print(f"  📱 App: {APP_PATH}")
    print()
    print("  ┌────────────────────────────────────────────────────────┐")
    print("  │                                                        │")
    print("  │  Apri nel browser:                                     │")
    print(f"  │     http://{ip}:{PORT}                            │")
    print("  │                                                        │")
    print("  │  Oppure su questo PC:                                  │")
    print(f"  │     http://localhost:{PORT}                            │")
    print("  │                                                        │")
    print("  └────────────────────────────────────────────────────────┘")
    print()
    print("  Premi CTRL+C per fermare il server")
    print()
    print("─" * 60)
    print()
    
    server = HTTPServer((HOST, PORT), ArchiveHandler)
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n\nServer fermato.")
        server.shutdown()


if __name__ == '__main__':
    main()
